class Pat7
{
   public static void main(String args[])
 {
	 //for upper/increment pyramid
  for(int i=1;i<=5;i++)
   {
    for(int j=5;j>=i;j--)//for space
    {
     System.out.print(" ");
	}
	for(int j=1;j<=2*i-1;j++)//for upper pyramid this logic imp
	{
		System.out.print("*");
	}
	System.out.println();
   }
   //for decrement pyramid
   for(int i=4;i>=1;i--)//i=4 for avoid repeatation of line
   {
	   for(int j=5;j>=i;j--)
	   {
		   System.out.print(" ");
	   }
	   for(int j=1;j<=2*i-1;j++)
	   {
		   System.out.print("*");
	   }
	   
	   System.out.println();
   }
   }
}


/*
    *
   ***
  *****
 *******
*********
 *******
  *****
   ***
    *
*/